"""Version information for mdllama"""

__version__ = "20250718.1"
