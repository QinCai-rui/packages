"""
Entry point for running mdllama as a module with `python -m mdllama`
"""

from .main import main

if __name__ == "__main__":
    main()
