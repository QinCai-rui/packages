"""Version information for mdllama"""

__version__ = "20250725.1"