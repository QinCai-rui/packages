"""Version information for mdllama"""

__version__ = "3.3.3"
