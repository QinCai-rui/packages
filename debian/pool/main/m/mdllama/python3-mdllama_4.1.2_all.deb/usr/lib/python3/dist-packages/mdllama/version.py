"""Version information for mdllama"""

__version__ = "4.1.2"