"""Version information for mdllama"""

__version__ = "4.0.0"